This directory contains rally benchmark scenarios to be run by OpenStack CI.


* more about rally: https://wiki.openstack.org/wiki/Rally
* how to add rally-gates: https://wiki.openstack.org/wiki/Rally/RallyGates
