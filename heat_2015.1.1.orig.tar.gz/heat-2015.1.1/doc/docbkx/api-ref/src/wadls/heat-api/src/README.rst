=========
HEAT wadl
=========

The original heat wadl (heat-api-1.0.wadl) and the samples have now been deleted from this repository.

The wadl has been renamed and migrated to the following repo location along with the samples:
https://github.com/openstack/api-site/blob/master/api-ref/src/wadls/orchestration-api/src/v1/orchestration-api.wadl

