Ceilometer Style Commandments
=============================

- Step 1: Read the OpenStack Style Commandments
  http://docs.openstack.org/developer/hacking/
- Step 2: Read on

Ceilometer Specific Commandments
--------------------------------

- [C300] Check for oslo library imports use the non-namespaced packages
