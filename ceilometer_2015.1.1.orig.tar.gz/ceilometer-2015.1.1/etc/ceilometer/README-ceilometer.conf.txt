To generate the sample ceilometer.conf file, run the following
command from the top-level ceilometer directory:

tox -egenconfig