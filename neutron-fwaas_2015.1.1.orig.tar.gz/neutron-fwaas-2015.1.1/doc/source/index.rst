.. documentation master file

====
Main
====

.. toctree::
   :glob:
   :maxdepth: 1

   main/*

==================
Indices and tables
==================

* :ref:`search`
